﻿Imports System.Data.SqlClient
Public Class Form1
    Private Sub bGuardar_Click(sender As Object, e As EventArgs) Handles bGuardar.Click
        insertar()
        limpiar()
    End Sub
    Sub insertar()
        Dim con As New SqlConnection(My.Settings.EmpleadosConnectionString)
        con.Open()
        Dim nombre, apellido, sexo, departamento As String
        Dim edad As Integer
        Dim salario As Decimal
        nombre = tbNombre.Text
        apellido = tbApellido.Text
        If rbMasculino.Checked = True Then
            sexo = rbMasculino.Text
        End If
        If rbFemenino.Checked = True Then
            sexo = rbFemenino.Text
        End If

        departamento = cbDepartamento.SelectedItem
        'CInt() = transforma a entero
        edad = CInt(tbEdad.Text)
        'CDec()= transforma a decimal 
        salario = CDec(tbSalario.Text)
        Dim sql As String = "Insert Into Planilla (Nombre, Apellido, Sexo, Edad, Departamento, Salario) Values ('" & nombre & "', '" & apellido & "', '" & sexo & "', '" & edad & "', '" & departamento & "', '" & salario & "')"
        Dim comando As New SqlCommand(sql, con)
        comando.ExecuteNonQuery()
        con.Close()
        MsgBox("Datos ingresados correctamente ")
    End Sub
    Sub limpiar()
        tbNombre.Clear()
        tbApellido.Clear()
        tbEdad.Clear()
        tbSalario.Clear()

        rbMasculino.Checked = False
        rbFemenino.Checked = False

        cbDepartamento.SelectedIndex = -1
    End Sub

    Private Sub bSiguiente_Click(sender As Object, e As EventArgs) Handles bSiguiente.Click
        Form2.Show()
        Me.Hide()
    End Sub
End Class
