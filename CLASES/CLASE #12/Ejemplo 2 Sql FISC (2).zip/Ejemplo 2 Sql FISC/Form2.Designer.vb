﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbRespuesta = New System.Windows.Forms.Label()
        Me.dgvReporte1 = New System.Windows.Forms.DataGridView()
        Me.bMostrar = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cbDepartamento = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cbSexo = New System.Windows.Forms.ComboBox()
        Me.bSiguiente = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgvReporte1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbRespuesta)
        Me.GroupBox1.Controls.Add(Me.dgvReporte1)
        Me.GroupBox1.Controls.Add(Me.bMostrar)
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Location = New System.Drawing.Point(35, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(864, 508)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Resultados"
        '
        'lbRespuesta
        '
        Me.lbRespuesta.AutoSize = True
        Me.lbRespuesta.Location = New System.Drawing.Point(645, 330)
        Me.lbRespuesta.Name = "lbRespuesta"
        Me.lbRespuesta.Size = New System.Drawing.Size(0, 17)
        Me.lbRespuesta.TabIndex = 4
        '
        'dgvReporte1
        '
        Me.dgvReporte1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvReporte1.Location = New System.Drawing.Point(87, 261)
        Me.dgvReporte1.Name = "dgvReporte1"
        Me.dgvReporte1.RowHeadersWidth = 51
        Me.dgvReporte1.RowTemplate.Height = 24
        Me.dgvReporte1.Size = New System.Drawing.Size(483, 177)
        Me.dgvReporte1.TabIndex = 3
        '
        'bMostrar
        '
        Me.bMostrar.Location = New System.Drawing.Point(270, 165)
        Me.bMostrar.Name = "bMostrar"
        Me.bMostrar.Size = New System.Drawing.Size(75, 23)
        Me.bMostrar.TabIndex = 2
        Me.bMostrar.Text = "Mostrar"
        Me.bMostrar.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cbDepartamento)
        Me.GroupBox3.Location = New System.Drawing.Point(370, 43)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Departamento"
        '
        'cbDepartamento
        '
        Me.cbDepartamento.FormattingEnabled = True
        Me.cbDepartamento.Items.AddRange(New Object() {"Producción", "TI", "Contabilidad", "Recursos Humanos"})
        Me.cbDepartamento.Location = New System.Drawing.Point(19, 48)
        Me.cbDepartamento.Name = "cbDepartamento"
        Me.cbDepartamento.Size = New System.Drawing.Size(121, 24)
        Me.cbDepartamento.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cbSexo)
        Me.GroupBox2.Location = New System.Drawing.Point(28, 43)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Sexo"
        '
        'cbSexo
        '
        Me.cbSexo.FormattingEnabled = True
        Me.cbSexo.Items.AddRange(New Object() {"Masculino", "Femenino"})
        Me.cbSexo.Location = New System.Drawing.Point(49, 48)
        Me.cbSexo.Name = "cbSexo"
        Me.cbSexo.Size = New System.Drawing.Size(121, 24)
        Me.cbSexo.TabIndex = 0
        '
        'bSiguiente
        '
        Me.bSiguiente.Location = New System.Drawing.Point(706, 545)
        Me.bSiguiente.Name = "bSiguiente"
        Me.bSiguiente.Size = New System.Drawing.Size(75, 23)
        Me.bSiguiente.TabIndex = 1
        Me.bSiguiente.Text = "Siguiente"
        Me.bSiguiente.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(943, 610)
        Me.Controls.Add(Me.bSiguiente)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form2"
        Me.Text = "Reportes"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgvReporte1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents dgvReporte1 As DataGridView
    Friend WithEvents bMostrar As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lbRespuesta As Label
    Friend WithEvents cbDepartamento As ComboBox
    Friend WithEvents cbSexo As ComboBox
    Friend WithEvents bSiguiente As Button
End Class
