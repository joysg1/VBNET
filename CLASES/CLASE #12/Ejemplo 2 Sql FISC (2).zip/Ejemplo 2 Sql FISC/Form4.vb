﻿Imports System.Data.SqlClient
Public Class Form4
    Dim con As New SqlConnection(My.Settings.EmpleadosConnectionString)
    Dim nombre, apellido, departamento As String
    Dim edad As Integer

    Private Sub bEditar_Click(sender As Object, e As EventArgs) Handles bEditar.Click

        con.Open()
        AsignarValores()

        Dim update_sql As String = "Update Planilla set Edad = '" & edad & " ', Departamento = '" & departamento & " ', Salario = '" & salario & "' Where Nombre Like '%" & nombre & "%' And Apellido Like '%" & apellido & "%'  "
        Dim comando As New SqlCommand(update_sql, con)
        Dim cambios As Integer
        cambios = comando.ExecuteNonQuery()
        If cambios = 0 Then
            MsgBox("El usuario no existe")
        Else
            MsgBox("Información ha sido actualizada ")
        End If
        con.Close()
    End Sub

    Private Sub bBorrar_Click(sender As Object, e As EventArgs) Handles bBorrar.Click
        con.Open()
        AsignarValores()
        Dim delete_sql As String = "Delete from Planilla Where Nombre Like '%" & nombre & "%' And Apellido Like '%" & apellido & "%' "
        Dim comando As New SqlCommand(delete_sql, con)
        comando.ExecuteNonQuery()
        con.Close()
    End Sub

    Dim salario As Decimal


    Sub AsignarValores()
        nombre = tbNombre.Text
        apellido = tbApellido.Text
        departamento = cbDepartamento.SelectedItem
        edad = Val(tbEdad.Text)
        salario = Val(tbSalario.Text)
    End Sub
End Class