﻿Imports System.Data.SqlClient
Public Class Form3
    Dim con As New SqlConnection(My.Settings.PruebaConnectionString)
    Dim a, b As Integer
    Private Sub bConsultar_Click(sender As Object, e As EventArgs) Handles bConsultar.Click
        If rb1.Checked = True Then
            a = 0
            b = 20
        End If
        If rb2.Checked = True Then
            a = 21
            b = 61

        End If
        If rb3.Checked = True Then
            a = 62
            b = 122
        End If
        con.Open()
        consultar()
    End Sub

    Sub consultar()

        Dim sql As String = "Select Nombre, Edad from Data Where Edad >= '" & a & "' AND Edad <= ' " & b & " ' "
        Dim cmd As New SqlCommand(sql, con)
        Try
            Dim Da As New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            Da.Fill(ds, "Data")
            Me.DGVResultados.DataSource = ds.Tables("Data")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Dim sql2 As String = "Select Count(*) from Data Where Edad >= '" & a & "' AND Edad <= ' " & b & " ' "
        Dim cmd2 As New SqlCommand(sql2, con)
        Dim Dr As SqlDataReader
        Dr = cmd2.ExecuteReader
        If Dr.Read Then
            lbResulados.Text = ("Cantidad de usuarios: " & Dr(0))
        End If
        con.Close()
    End Sub
End Class