﻿Imports System.Data.SqlClient
Public Class Form1
    Private Sub bMostrar_Click(sender As Object, e As EventArgs) Handles bMostrar.Click
        Dim con As New SqlConnection(My.Settings.PruebaConnectionString)
        Dim sql As String = "Select id, Nombre, Edad From Data"
        Dim cmd As New SqlCommand(sql, con)
        Try
            Dim da As New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds, "Data")
            Me.dgvDatos.DataSource = ds.Tables("Data")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.MsgBoxHelp)
        End Try
    End Sub

    Private Sub bSiguiente_Click(sender As Object, e As EventArgs) Handles bSiguiente.Click
        Form2.Show()
        Me.Hide()

    End Sub
End Class
