﻿Imports System.Data.SqlClient
Public Class Form2
    Private Sub bInsertar_Click(sender As Object, e As EventArgs) Handles bInsertar.Click
        Dim con As New SqlConnection(My.Settings.PruebaConnectionString)
        con.Open()
        Dim nombre As String
        Dim edad As Integer
        nombre = tbNombre.Text
        edad = Val(tbEdad.Text)

        Dim sql As String = "Insert into Data (Nombre, Edad) Values ('" & nombre & "', '" & edad & "' )"
        Dim cmd As New SqlCommand(sql, con)
        cmd.ExecuteNonQuery()
        con.Close()
        MsgBox("Datos ingresados correctamente ")
    End Sub
End Class