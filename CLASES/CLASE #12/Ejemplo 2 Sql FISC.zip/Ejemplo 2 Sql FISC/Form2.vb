﻿Imports System.Data.SqlClient
Public Class Form2
    Dim sexo, departamento As String
    Dim con As New SqlConnection(My.Settings.EmpleadosConnectionString)
    Private Sub bMostrar_Click(sender As Object, e As EventArgs) Handles bMostrar.Click
        sexo = cbSexo.SelectedItem
        departamento = cbDepartamento.SelectedItem

        con.Open()
        consulta()
    End Sub

    Sub consulta()
        Dim sql As String = "Select Nombre, Apellido, Edad from Planilla Where Sexo Like '%" & sexo & "%' And Departamento Like '%" & departamento & "%'  "
        Dim cmd As New SqlCommand(sql, con)
        Try
            Dim Da As New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            Da.Fill(ds, "Planilla")
            Me.dgvReporte1.DataSource = ds.Tables("Planilla")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Dim sql2 As String = "Select Count (*) from Planilla Where Sexo Like '%" & sexo & "%' And Departamento Like '%" & departamento & "%'  "
        Dim cmd2 As New SqlCommand(sql2, con)
        Dim DR As SqlDataReader
        DR = cmd2.ExecuteReader
        If DR.Read Then
            lbRespuesta.Text = "Cantidad de empleados: " & DR(0)
        End If

        con.Close()
    End Sub


End Class