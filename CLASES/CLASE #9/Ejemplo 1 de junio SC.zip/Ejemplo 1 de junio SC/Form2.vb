﻿Imports System.ComponentModel

Public Class Form2
    Private Sub tbNombre_Validating(sender As Object, e As CancelEventArgs) Handles tbNombre.Validating
        If tbNombre.Text = "" Then
            ErrorProvider1.SetError(tbNombre, "Escriba su nombre")
            e.Cancel = True
        Else
            ErrorProvider1.SetError(tbNombre, "")
            e.Cancel = False
        End If
    End Sub

    Private Sub bEnviar_Click(sender As Object, e As EventArgs) Handles bEnviar.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub rbSi_CheckedChanged(sender As Object, e As EventArgs) Handles rbSi.CheckedChanged
        Label5.Visible = True
        tbEmpresa.Visible = True
    End Sub

    Private Sub rbNo_CheckedChanged(sender As Object, e As EventArgs) Handles rbNo.CheckedChanged
        Label5.Visible = False
        tbEmpresa.Visible = False
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label5.Visible = False
        tbEmpresa.Visible = False
    End Sub
End Class