﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbNombre.Text = "Su nombre es: " & Form2.tbNombre.Text
        lbNacimiento.Text = "Su fecha de nacimiento es: " & Form2.Calendario.Value.Date
        If Form2.rbSecundario.Checked = True Then
            lbNivel.Text = "Tiene estudios de nivel secundario"
        End If
        If Form2.rbUniversitario.Checked = True Then
            lbNivel.Text = "Tiene estudios de nivel universitario "
        End If
        lbInstitucion.Text = "Graduado en : " & Form2.tbInstitución.Text

        If Form2.rbSi.Checked = True Then
            lbExperiencia.Text = "Usted cuenta con experiencia laboral en la empresa " & Form2.tbEmpresa.Text
        End If

        If Form2.rbNo.Checked = True Then
            lbExperiencia.Text = "Usted no cuenta con experiencia laboral"
        End If
    End Sub
End Class