﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.lbNacimiento = New System.Windows.Forms.Label()
        Me.lbNombre = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.lbInstitucion = New System.Windows.Forms.Label()
        Me.lbNivel = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.lbExperiencia = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(762, 426)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.lbNacimiento)
        Me.TabPage1.Controls.Add(Me.lbNombre)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(754, 397)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Datos personales"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'lbNacimiento
        '
        Me.lbNacimiento.AutoSize = True
        Me.lbNacimiento.Location = New System.Drawing.Point(71, 147)
        Me.lbNacimiento.Name = "lbNacimiento"
        Me.lbNacimiento.Size = New System.Drawing.Size(0, 17)
        Me.lbNacimiento.TabIndex = 1
        '
        'lbNombre
        '
        Me.lbNombre.AutoSize = True
        Me.lbNombre.Location = New System.Drawing.Point(68, 77)
        Me.lbNombre.Name = "lbNombre"
        Me.lbNombre.Size = New System.Drawing.Size(0, 17)
        Me.lbNombre.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.lbInstitucion)
        Me.TabPage2.Controls.Add(Me.lbNivel)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(754, 397)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos Académicos"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'lbInstitucion
        '
        Me.lbInstitucion.AutoSize = True
        Me.lbInstitucion.Location = New System.Drawing.Point(61, 183)
        Me.lbInstitucion.Name = "lbInstitucion"
        Me.lbInstitucion.Size = New System.Drawing.Size(0, 17)
        Me.lbInstitucion.TabIndex = 1
        '
        'lbNivel
        '
        Me.lbNivel.AutoSize = True
        Me.lbNivel.Location = New System.Drawing.Point(58, 72)
        Me.lbNivel.Name = "lbNivel"
        Me.lbNivel.Size = New System.Drawing.Size(0, 17)
        Me.lbNivel.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.lbExperiencia)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(754, 397)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Datos Laborales"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'lbExperiencia
        '
        Me.lbExperiencia.AutoSize = True
        Me.lbExperiencia.Location = New System.Drawing.Point(71, 60)
        Me.lbExperiencia.Name = "lbExperiencia"
        Me.lbExperiencia.Size = New System.Drawing.Size(0, 17)
        Me.lbExperiencia.TabIndex = 0
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(808, 465)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form3"
        Me.Text = "Tab Control"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents lbNacimiento As Label
    Friend WithEvents lbNombre As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents lbInstitucion As Label
    Friend WithEvents lbNivel As Label
    Friend WithEvents lbExperiencia As Label
End Class
