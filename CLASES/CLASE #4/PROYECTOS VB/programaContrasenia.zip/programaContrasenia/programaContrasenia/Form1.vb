﻿Public Class Form1
    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        Dim contrasenia As String
        contrasenia = tbcontrasenia.Text

        If contrasenia <> "12345" Then
            MsgBox("Usuario o contraseña incorrecta")
        Else

            Form2.Show()
            Me.Hide()


        End If



    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbContrasenia.Visible = False
        tbcontrasenia.Visible = False
        btnAceptar.Enabled = False


    End Sub

    Private Sub tbNombre_TextChanged(sender As Object, e As EventArgs) Handles tbNombre.TextChanged
        lbContrasenia.Visible = True
        tbcontrasenia.Visible = True

        Validar()


    End Sub

    Private Sub tbcontrasenia_TextChanged(sender As Object, e As EventArgs) Handles tbcontrasenia.TextChanged

        Validar()

    End Sub


    Sub Validar()


        If tbNombre.Text <> "" And tbcontrasenia.Text <> "" Then
            btnAceptar.Enabled = True

        End If



        If tbNombre.Text = "" Or tbcontrasenia.Text = "" Then
            btnAceptar.Enabled = False

        End If
    End Sub



End Class
