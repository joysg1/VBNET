﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbBienve.Text = "Bienvenido " + Form1.tbNombre.Text

    End Sub

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        Dim base, altura As Integer
        Dim respuesta As String

        base = Val(tbBase.Text)
        altura = Val(tbAltura.Text)

        If (base = altura Or base <= 0 Or altura <= 0 Or base > 100 Or altura > 200) Then
            MsgBox("Verifique los datos ingresados")

        Else
            respuesta = base * altura
            lbRespuesta.Text = "El area del rectangulo es de " + respuesta

        End If

    End Sub
End Class