﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbBienve = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbBase = New System.Windows.Forms.TextBox()
        Me.tbAltura = New System.Windows.Forms.TextBox()
        Me.btnAceptar = New System.Windows.Forms.Button()
        Me.lbRespuesta = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbBienve
        '
        Me.lbBienve.AutoSize = True
        Me.lbBienve.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbBienve.Location = New System.Drawing.Point(177, 46)
        Me.lbBienve.Name = "lbBienve"
        Me.lbBienve.Size = New System.Drawing.Size(0, 32)
        Me.lbBienve.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(40, 118)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Ingrese la base"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 179)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(110, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Ingrese la altura"
        '
        'tbBase
        '
        Me.tbBase.Location = New System.Drawing.Point(218, 115)
        Me.tbBase.Name = "tbBase"
        Me.tbBase.Size = New System.Drawing.Size(100, 22)
        Me.tbBase.TabIndex = 3
        '
        'tbAltura
        '
        Me.tbAltura.Location = New System.Drawing.Point(218, 172)
        Me.tbAltura.Name = "tbAltura"
        Me.tbAltura.Size = New System.Drawing.Size(100, 22)
        Me.tbAltura.TabIndex = 4
        '
        'btnAceptar
        '
        Me.btnAceptar.Location = New System.Drawing.Point(252, 244)
        Me.btnAceptar.Name = "btnAceptar"
        Me.btnAceptar.Size = New System.Drawing.Size(131, 47)
        Me.btnAceptar.TabIndex = 5
        Me.btnAceptar.Text = "CALCULAR"
        Me.btnAceptar.UseVisualStyleBackColor = True
        '
        'lbRespuesta
        '
        Me.lbRespuesta.AutoSize = True
        Me.lbRespuesta.Location = New System.Drawing.Point(359, 175)
        Me.lbRespuesta.Name = "lbRespuesta"
        Me.lbRespuesta.Size = New System.Drawing.Size(0, 17)
        Me.lbRespuesta.TabIndex = 6
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(594, 303)
        Me.Controls.Add(Me.lbRespuesta)
        Me.Controls.Add(Me.btnAceptar)
        Me.Controls.Add(Me.tbAltura)
        Me.Controls.Add(Me.tbBase)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbBienve)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbBienve As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbBase As TextBox
    Friend WithEvents tbAltura As TextBox
    Friend WithEvents btnAceptar As Button
    Friend WithEvents lbRespuesta As Label
End Class
