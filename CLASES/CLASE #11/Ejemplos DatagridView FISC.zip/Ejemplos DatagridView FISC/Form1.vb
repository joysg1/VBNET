﻿Public Class Form1
    Dim cantidad As Integer
    Private Sub bDataGrid_Click(sender As Object, e As EventArgs) Handles bDataGrid.Click
        'Creación de Datagridview
        cantidadEstudiantes()
        'Cantidad de filas 
        dgvNotas.RowCount = cantidad
        'Cantidad de columnas
        dgvNotas.ColumnCount = 10
        'ancho de la cabecera
        dgvNotas.RowHeadersWidth = 70
        'tipo, estilo y tamaño de la letra del encabezado 
        dgvNotas.RowHeadersDefaultCellStyle.Font =
            New Font("Arial Narrow", 10, FontStyle.Bold)
        'construir las filas
        For i = 1 To cantidad - 1
            dgvNotas.Rows(i - 1).HeaderCell.Value = Str(i)
        Next
        'alineación
        dgvNotas.ColumnHeadersDefaultCellStyle.Alignment =
            DataGridViewContentAlignment.MiddleCenter
        'tipo, estilo y tamaño de la letra de las celdas
        dgvNotas.ColumnHeadersDefaultCellStyle.Font =
            New Font("Arial", 9, FontStyle.Regular)
        'Construcción de las columnas
        dgvNotas.Columns(0).HeaderText = "Apellido"
        dgvNotas.Columns(0).Name = "Apellido"
        dgvNotas.Columns(0).Width = 125

        dgvNotas.Columns(1).HeaderText = "Nombre"
        dgvNotas.Columns(1).Name = "Nombre"
        dgvNotas.Columns(1).Width = 125

        dgvNotas.Columns(2).HeaderText = "Cédula"
        dgvNotas.Columns(2).Name = "Cédula"
        dgvNotas.Columns(2).Width = 125

        dgvNotas.Columns(3).HeaderText = "Parcial #1"
        dgvNotas.Columns(3).Name = "parcial1"
        dgvNotas.Columns(3).Width = 75

        dgvNotas.Columns(4).HeaderText = "Parcial #2"
        dgvNotas.Columns(4).Name = "parcial2"
        dgvNotas.Columns(4).Width = 75

        dgvNotas.Columns(5).HeaderText = "Parcial #3"
        dgvNotas.Columns(5).Name = "parcial3"
        dgvNotas.Columns(5).Width = 75

        dgvNotas.Columns(6).HeaderText = "Semestral"
        dgvNotas.Columns(6).Name = "semestral"
        dgvNotas.Columns(6).Width = 75


        dgvNotas.Columns(7).HeaderText = "Promedio de parciales"
        dgvNotas.Columns(7).Name = "promparciales"
        dgvNotas.Columns(7).Width = 75


        dgvNotas.Columns(8).HeaderText = "Promedio de semestral"
        dgvNotas.Columns(8).Name = "promsemestral"
        dgvNotas.Columns(8).Width = 75


        dgvNotas.Columns(9).HeaderText = "Nota"
        dgvNotas.Columns(9).Name = "nota"
        dgvNotas.Columns(9).Width = 75

        'Solo lectura las columnas 7, 8 , 9
        dgvNotas.Columns(7).ReadOnly = True
        dgvNotas.Columns(8).ReadOnly = True
        dgvNotas.Columns(9).ReadOnly = True

        'Asignar colores
        dgvNotas.Columns(6).DefaultCellStyle.BackColor = Color.Thistle
        dgvNotas.Columns(7).DefaultCellStyle.BackColor = Color.YellowGreen
        dgvNotas.Columns(8).DefaultCellStyle.BackColor = Color.Aquamarine
        dgvNotas.Columns(9).DefaultCellStyle.BackColor = Color.Honeydew

        dgvNotas.Columns(9).DefaultCellStyle.Font =
            New Font("Arial", 11, FontStyle.Bold)
        'Centrar la información
        dgvNotas.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter


    End Sub
    Private Sub bCalcular_Click(sender As Object, e As EventArgs) Handles bCalcular.Click
        Dim p1, p2, p3, semestral As Integer
        Dim promparcial, promfinal, promsemestral As Decimal
        Dim nota As Char
        Dim contA, contB, contC, contD, contF As Integer
        cantidadEstudiantes()
        contA = 0 : contB = 0 : contC = 0 : contD = 0 : contF = 0
        For i = 0 To cantidad - 1
            p1 = Val(dgvNotas.Rows(i).Cells(3).Value)
            p2 = Val(dgvNotas.Rows(i).Cells(4).Value)
            p3 = Val(dgvNotas.Rows(i).Cells(5).Value)
            semestral = Val(dgvNotas.Rows(i).Cells(6).Value)

            promparcial = ((p1 + p2 + p3) / 3) * 0.6
            promsemestral = semestral * 0.4
            promfinal = promparcial + promsemestral

            Select Case promfinal
                Case 0 To 60.9999
                    nota = "F"
                    contF = contF + 1

                Case 61 To 70.9999
                    nota = "D"
                    contD = contD + 1
                Case 71 To 80.9999
                    nota = "C"
                    contC = contC + 1
                Case 81 To 90.9999
                    nota = "B"
                    contB = contB + 1
                Case 91 To 100
                    nota = "A"
                    contA = contA + 1
            End Select
            dgvNotas.Rows(i).Cells(7).Value = promparcial
            dgvNotas.Rows(i).Cells(8).Value = promfinal
            dgvNotas.Rows(i).Cells(9).Value = nota
        Next
        lbA.Text = ("Estudiantes con A: " & contA)
        lbB.Text = ("Estudiantes con B: " & contB)
        lbC.Text = ("Estudiantes con C: " & contC)
        lbD.Text = ("Estudiantes con D: " & contD)
        lbF.Text = ("Estudiantes con F: " & contF)
    End Sub

    Sub cantidadEstudiantes()

        cantidad = Val(tbCantidad.Text)
    End Sub
End Class
