﻿Public Class Form3
    Private Sub bGenerar_Click(sender As Object, e As EventArgs) Handles bGenerar.Click
        Dim filas, columnas, matriz(,) As Integer
        filas = Val(tbFilas.Text)
        columnas = Val(tbColumnas.Text)
        ReDim matriz(filas, columnas)

        'cantidad de filas
        dgvNumeros.RowCount = filas
        'Cantidad de columnas
        dgvNumeros.ColumnCount = columnas

        dgvNumeros.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        For i = 0 To (filas - 1)
            For j = 0 To (columnas - 1)
                matriz(i, j) = Int((999 - 1 + 1) * Rnd() + 1)
                dgvNumeros.Rows(i).Cells(j).Value = matriz(i, j)

            Next
        Next


    End Sub
End Class