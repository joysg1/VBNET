﻿Public Class Form2
    Private Sub bLlenar_Click(sender As Object, e As EventArgs) Handles bLlenar.Click
        Dim cantidad, numeros() As Integer
        'crear un vector de n elementos
        cantidad = Val(tbCantidad.Text)
        ReDim numeros(cantidad)
        'Llenar el vector 
        For i = 0 To cantidad - 1
            numeros(i) = Val(InputBox("Ingresa un número "))
        Next

        DataGridView1.Columns.Add("elementos", "Elementos Ordenados")
        'llenar el DatagridView
        For i = 0 To cantidad - 1
            DataGridView1.Rows.Add(1)
            DataGridView1.Item(0, i).Value = numeros(i)

        Next
    End Sub

    Private Sub bSiguiente_Click(sender As Object, e As EventArgs) Handles bSiguiente.Click
        Form3.Show()
        Me.Hide()
    End Sub
End Class