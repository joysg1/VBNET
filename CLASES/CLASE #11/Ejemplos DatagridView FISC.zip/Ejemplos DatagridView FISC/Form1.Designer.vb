﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbCantidad = New System.Windows.Forms.TextBox()
        Me.dgvNotas = New System.Windows.Forms.DataGridView()
        Me.bDataGrid = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbA = New System.Windows.Forms.Label()
        Me.lbB = New System.Windows.Forms.Label()
        Me.lbC = New System.Windows.Forms.Label()
        Me.lbD = New System.Windows.Forms.Label()
        Me.lbF = New System.Windows.Forms.Label()
        Me.bCalcular = New System.Windows.Forms.Button()
        Me.BSiguiente = New System.Windows.Forms.Button()
        CType(Me.dgvNotas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(98, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cantidad de estudiantes"
        '
        'tbCantidad
        '
        Me.tbCantidad.Location = New System.Drawing.Point(294, 59)
        Me.tbCantidad.Name = "tbCantidad"
        Me.tbCantidad.Size = New System.Drawing.Size(100, 22)
        Me.tbCantidad.TabIndex = 1
        '
        'dgvNotas
        '
        Me.dgvNotas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvNotas.Location = New System.Drawing.Point(36, 113)
        Me.dgvNotas.Name = "dgvNotas"
        Me.dgvNotas.RowHeadersWidth = 51
        Me.dgvNotas.RowTemplate.Height = 24
        Me.dgvNotas.Size = New System.Drawing.Size(1312, 312)
        Me.dgvNotas.TabIndex = 2
        '
        'bDataGrid
        '
        Me.bDataGrid.Location = New System.Drawing.Point(538, 48)
        Me.bDataGrid.Name = "bDataGrid"
        Me.bDataGrid.Size = New System.Drawing.Size(166, 38)
        Me.bDataGrid.TabIndex = 3
        Me.bDataGrid.Text = "Generar Data Grid"
        Me.bDataGrid.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbF)
        Me.GroupBox1.Controls.Add(Me.lbD)
        Me.GroupBox1.Controls.Add(Me.lbC)
        Me.GroupBox1.Controls.Add(Me.lbB)
        Me.GroupBox1.Controls.Add(Me.lbA)
        Me.GroupBox1.Location = New System.Drawing.Point(55, 453)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(605, 216)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Totales"
        '
        'lbA
        '
        Me.lbA.AutoSize = True
        Me.lbA.Location = New System.Drawing.Point(28, 33)
        Me.lbA.Name = "lbA"
        Me.lbA.Size = New System.Drawing.Size(0, 17)
        Me.lbA.TabIndex = 0
        '
        'lbB
        '
        Me.lbB.AutoSize = True
        Me.lbB.Location = New System.Drawing.Point(28, 76)
        Me.lbB.Name = "lbB"
        Me.lbB.Size = New System.Drawing.Size(0, 17)
        Me.lbB.TabIndex = 1
        '
        'lbC
        '
        Me.lbC.AutoSize = True
        Me.lbC.Location = New System.Drawing.Point(28, 121)
        Me.lbC.Name = "lbC"
        Me.lbC.Size = New System.Drawing.Size(0, 17)
        Me.lbC.TabIndex = 2
        '
        'lbD
        '
        Me.lbD.AutoSize = True
        Me.lbD.Location = New System.Drawing.Point(28, 155)
        Me.lbD.Name = "lbD"
        Me.lbD.Size = New System.Drawing.Size(0, 17)
        Me.lbD.TabIndex = 3
        '
        'lbF
        '
        Me.lbF.AutoSize = True
        Me.lbF.Location = New System.Drawing.Point(28, 183)
        Me.lbF.Name = "lbF"
        Me.lbF.Size = New System.Drawing.Size(0, 17)
        Me.lbF.TabIndex = 4
        '
        'bCalcular
        '
        Me.bCalcular.Location = New System.Drawing.Point(925, 552)
        Me.bCalcular.Name = "bCalcular"
        Me.bCalcular.Size = New System.Drawing.Size(149, 49)
        Me.bCalcular.TabIndex = 5
        Me.bCalcular.Text = "Calcular"
        Me.bCalcular.UseVisualStyleBackColor = True
        '
        'BSiguiente
        '
        Me.BSiguiente.Location = New System.Drawing.Point(1325, 646)
        Me.BSiguiente.Name = "BSiguiente"
        Me.BSiguiente.Size = New System.Drawing.Size(75, 23)
        Me.BSiguiente.TabIndex = 6
        Me.BSiguiente.Text = "Siguiente"
        Me.BSiguiente.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1424, 686)
        Me.Controls.Add(Me.BSiguiente)
        Me.Controls.Add(Me.bCalcular)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.bDataGrid)
        Me.Controls.Add(Me.dgvNotas)
        Me.Controls.Add(Me.tbCantidad)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Ejemplo #1"
        CType(Me.dgvNotas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents tbCantidad As TextBox
    Friend WithEvents dgvNotas As DataGridView
    Friend WithEvents bDataGrid As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lbF As Label
    Friend WithEvents lbD As Label
    Friend WithEvents lbC As Label
    Friend WithEvents lbB As Label
    Friend WithEvents lbA As Label
    Friend WithEvents bCalcular As Button
    Friend WithEvents BSiguiente As Button
End Class
