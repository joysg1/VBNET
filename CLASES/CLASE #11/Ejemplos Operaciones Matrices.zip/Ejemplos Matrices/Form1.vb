﻿Public Class Form1
    Dim matriz1(2, 2), matriz2(2, 2), resultado(2, 2) As Integer

    Private Sub bSuma_Click(sender As Object, e As EventArgs) Handles bSuma.Click
        For i = 1 To 2
            For j = 1 To 2
                resultado(i, j) = matriz1(i, j) + matriz2(i, j)
                MsgBox("Resultado" & i & " , " & j & " : " & resultado(i, j))
            Next
        Next
    End Sub

    Private Sub bSiguiente_Click(sender As Object, e As EventArgs) Handles bSiguiente.Click
        Form2.Show()
        Me.Hide()

    End Sub

    Private Sub bLlenarMatriz2_Click(sender As Object, e As EventArgs) Handles bLlenarMatriz2.Click
        For i = 1 To 2
            For j = 1 To 2
                matriz2(i, j) = Val(InputBox("Ingrese los elementos a la matriz 2 Elemento" & i & " , " & j))

            Next
        Next
    End Sub

    Private Sub bLlenarMatriz1_Click(sender As Object, e As EventArgs) Handles bLlenarMatriz1.Click
        For i = 1 To 2
            For j = 1 To 2
                matriz1(i, j) = Val(InputBox("Ingrese los elementos a la matriz 1 Elemento" & i & " , " & j))

            Next
        Next
    End Sub
End Class
