﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.bLlenarMatriz1 = New System.Windows.Forms.Button()
        Me.tbColumnas1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbFilas1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.bLLenarMatriz2 = New System.Windows.Forms.Button()
        Me.tbColumnas2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbFilas2 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.bMultiplicar = New System.Windows.Forms.Button()
        Me.bSiguiente = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.bLlenarMatriz1)
        Me.GroupBox1.Controls.Add(Me.tbColumnas1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.tbFilas1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(41, 28)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(251, 160)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Matriz 1"
        '
        'bLlenarMatriz1
        '
        Me.bLlenarMatriz1.Location = New System.Drawing.Point(132, 131)
        Me.bLlenarMatriz1.Name = "bLlenarMatriz1"
        Me.bLlenarMatriz1.Size = New System.Drawing.Size(113, 29)
        Me.bLlenarMatriz1.TabIndex = 4
        Me.bLlenarMatriz1.Text = "Llenar Matriz"
        Me.bLlenarMatriz1.UseVisualStyleBackColor = True
        '
        'tbColumnas1
        '
        Me.tbColumnas1.Location = New System.Drawing.Point(116, 97)
        Me.tbColumnas1.Name = "tbColumnas1"
        Me.tbColumnas1.Size = New System.Drawing.Size(100, 22)
        Me.tbColumnas1.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Columnas"
        '
        'tbFilas1
        '
        Me.tbFilas1.Location = New System.Drawing.Point(116, 41)
        Me.tbFilas1.Name = "tbFilas1"
        Me.tbFilas1.Size = New System.Drawing.Size(100, 22)
        Me.tbFilas1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Filas"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.bLLenarMatriz2)
        Me.GroupBox2.Controls.Add(Me.tbColumnas2)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.tbFilas2)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(41, 257)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(251, 160)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Matriz 2"
        '
        'bLLenarMatriz2
        '
        Me.bLLenarMatriz2.Location = New System.Drawing.Point(132, 131)
        Me.bLLenarMatriz2.Name = "bLLenarMatriz2"
        Me.bLLenarMatriz2.Size = New System.Drawing.Size(113, 23)
        Me.bLLenarMatriz2.TabIndex = 5
        Me.bLLenarMatriz2.Text = "LLenar Matriz"
        Me.bLLenarMatriz2.UseVisualStyleBackColor = True
        '
        'tbColumnas2
        '
        Me.tbColumnas2.Location = New System.Drawing.Point(116, 97)
        Me.tbColumnas2.Name = "tbColumnas2"
        Me.tbColumnas2.Size = New System.Drawing.Size(100, 22)
        Me.tbColumnas2.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Columnas"
        '
        'tbFilas2
        '
        Me.tbFilas2.Location = New System.Drawing.Point(116, 41)
        Me.tbFilas2.Name = "tbFilas2"
        Me.tbFilas2.Size = New System.Drawing.Size(100, 22)
        Me.tbFilas2.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 17)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Filas"
        '
        'bMultiplicar
        '
        Me.bMultiplicar.Location = New System.Drawing.Point(393, 201)
        Me.bMultiplicar.Name = "bMultiplicar"
        Me.bMultiplicar.Size = New System.Drawing.Size(118, 51)
        Me.bMultiplicar.TabIndex = 2
        Me.bMultiplicar.Text = "Multiplicar"
        Me.bMultiplicar.UseVisualStyleBackColor = True
        '
        'bSiguiente
        '
        Me.bSiguiente.Location = New System.Drawing.Point(656, 403)
        Me.bSiguiente.Name = "bSiguiente"
        Me.bSiguiente.Size = New System.Drawing.Size(107, 35)
        Me.bSiguiente.TabIndex = 3
        Me.bSiguiente.Text = "Siguiente"
        Me.bSiguiente.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.bSiguiente)
        Me.Controls.Add(Me.bMultiplicar)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form2"
        Me.Text = "Multiplicación de matrices"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents bLlenarMatriz1 As Button
    Friend WithEvents tbColumnas1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents tbFilas1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents bLLenarMatriz2 As Button
    Friend WithEvents tbColumnas2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents tbFilas2 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents bMultiplicar As Button
    Friend WithEvents bSiguiente As Button
End Class
