﻿Public Class Form2
    Dim filas1, filas2, filas3, columnas1, columnas2, columnas3 As Integer

    Private Sub bSiguiente_Click(sender As Object, e As EventArgs) Handles bSiguiente.Click
        Form3.Show()
        Me.Hide()


    End Sub

    Private Sub bMultiplicar_Click(sender As Object, e As EventArgs) Handles bMultiplicar.Click
        Dim suma As Integer
        If columnas1 <> filas2 Then
            MsgBox("No puede realizarse la multiplicación de las matrices")
        Else
            filas3 = filas1
            columnas3 = columnas2
            ReDim producto(filas3, columnas3)
            For a = 1 To columnas2
                For i = 1 To filas1
                    suma = 0
                    For j = 1 To columnas1
                        suma = suma + matriz1(i, j) * matriz2(j, a)
                    Next
                    producto(i, a) = suma
                Next
            Next

            For i = 1 To filas3
                For j = 1 To columnas3
                    MsgBox("Elemento " & i & " , " & j & " : " & producto(i, j))
                Next
            Next
        End If
    End Sub

    Dim matriz1(,), matriz2(,), producto(,) As Integer
    Private Sub bLLenarMatriz2_Click(sender As Object, e As EventArgs) Handles bLLenarMatriz2.Click
        filas2 = Val(tbFilas2.Text)
        columnas2 = Val(tbColumnas2.Text)
        ReDim matriz2(filas2, columnas2)
        For i = 1 To filas2
            For j = 1 To columnas2
                matriz2(i, j) = Val(InputBox("Ingrese los elementos de la matriz 2. Elemento " & i & " , " & j & ": "))
            Next
        Next
    End Sub

    Private Sub bLlenarMatriz1_Click(sender As Object, e As EventArgs) Handles bLlenarMatriz1.Click
        filas1 = Val(tbFilas1.Text)
        columnas1 = Val(tbColumnas1.Text)
        ReDim matriz1(filas1, columnas1)
        For i = 1 To filas1
            For j = 1 To columnas1
                matriz1(i, j) = Val(InputBox("Ingrese los elementos de la matriz 1. Elemento " & i & " , " & j & ": "))
            Next
        Next
    End Sub


End Class