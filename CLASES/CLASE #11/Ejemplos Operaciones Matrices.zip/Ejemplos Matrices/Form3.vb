﻿Public Class Form3
    Private Sub bCalcular_Click(sender As Object, e As EventArgs) Handles bCalcular.Click
        Dim filas, columnas As Integer
        Dim matriz(,), inversa(,) As Integer
        filas = Val(tbFilas.Text)
        columnas = Val(tbColumnas.Text)

        ReDim matriz(filas, columnas)
        ReDim inversa(columnas, filas)

        For i = 1 To filas
            For j = 1 To columnas
                matriz(i, j) = Val(InputBox("Elemento " & i & " , " & j & " : "))
                inversa(j, i) = matriz(i, j)
            Next
        Next

        For i = 1 To columnas
            For j = 1 To filas
                MsgBox("Elemento " & i & " , " & j & " : " & inversa(i, j))
            Next
        Next
    End Sub
End Class