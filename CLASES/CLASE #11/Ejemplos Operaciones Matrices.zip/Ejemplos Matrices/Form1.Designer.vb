﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.bLlenarMatriz1 = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.bLlenarMatriz2 = New System.Windows.Forms.Button()
        Me.bSuma = New System.Windows.Forms.Button()
        Me.bSiguiente = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.bLlenarMatriz1)
        Me.GroupBox1.Location = New System.Drawing.Point(74, 28)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(270, 142)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Matriz 1"
        '
        'bLlenarMatriz1
        '
        Me.bLlenarMatriz1.Location = New System.Drawing.Point(50, 51)
        Me.bLlenarMatriz1.Name = "bLlenarMatriz1"
        Me.bLlenarMatriz1.Size = New System.Drawing.Size(161, 46)
        Me.bLlenarMatriz1.TabIndex = 0
        Me.bLlenarMatriz1.Text = "Llenar Matriz 1"
        Me.bLlenarMatriz1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.bLlenarMatriz2)
        Me.GroupBox2.Location = New System.Drawing.Point(84, 216)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(260, 166)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Matriz 2"
        '
        'bLlenarMatriz2
        '
        Me.bLlenarMatriz2.Location = New System.Drawing.Point(50, 60)
        Me.bLlenarMatriz2.Name = "bLlenarMatriz2"
        Me.bLlenarMatriz2.Size = New System.Drawing.Size(161, 46)
        Me.bLlenarMatriz2.TabIndex = 1
        Me.bLlenarMatriz2.Text = "Llenar Matriz 2"
        Me.bLlenarMatriz2.UseVisualStyleBackColor = True
        '
        'bSuma
        '
        Me.bSuma.Location = New System.Drawing.Point(401, 169)
        Me.bSuma.Name = "bSuma"
        Me.bSuma.Size = New System.Drawing.Size(275, 101)
        Me.bSuma.TabIndex = 2
        Me.bSuma.Text = "Suma de Matrices"
        Me.bSuma.UseVisualStyleBackColor = True
        '
        'bSiguiente
        '
        Me.bSiguiente.Location = New System.Drawing.Point(684, 401)
        Me.bSiguiente.Name = "bSiguiente"
        Me.bSiguiente.Size = New System.Drawing.Size(85, 37)
        Me.bSiguiente.TabIndex = 3
        Me.bSiguiente.Text = "Siguiente"
        Me.bSiguiente.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.bSiguiente)
        Me.Controls.Add(Me.bSuma)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Suma de matrices"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents bLlenarMatriz1 As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents bLlenarMatriz2 As Button
    Friend WithEvents bSuma As Button
    Friend WithEvents bSiguiente As Button
End Class
