﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbLimite = New System.Windows.Forms.TextBox()
        Me.bCalcular = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Bsiguiente = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(120, 127)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Límite"
        '
        'tbLimite
        '
        Me.tbLimite.Location = New System.Drawing.Point(220, 127)
        Me.tbLimite.Name = "tbLimite"
        Me.tbLimite.Size = New System.Drawing.Size(99, 22)
        Me.tbLimite.TabIndex = 1
        '
        'bCalcular
        '
        Me.bCalcular.Location = New System.Drawing.Point(326, 221)
        Me.bCalcular.Name = "bCalcular"
        Me.bCalcular.Size = New System.Drawing.Size(118, 44)
        Me.bCalcular.TabIndex = 2
        Me.bCalcular.Text = "Calcular"
        Me.bCalcular.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(214, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(251, 32)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Serie de Fibonacci"
        '
        'Bsiguiente
        '
        Me.Bsiguiente.Location = New System.Drawing.Point(634, 336)
        Me.Bsiguiente.Name = "Bsiguiente"
        Me.Bsiguiente.Size = New System.Drawing.Size(83, 51)
        Me.Bsiguiente.TabIndex = 4
        Me.Bsiguiente.Text = "Siguiente"
        Me.Bsiguiente.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Bsiguiente)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.bCalcular)
        Me.Controls.Add(Me.tbLimite)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Ciclo While"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents tbLimite As TextBox
    Friend WithEvents bCalcular As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Bsiguiente As Button
End Class
