﻿Public Class Form2
    Private Sub bCalcular_Click(sender As Object, e As EventArgs) Handles bCalcular.Click
        Dim cantidadR As Integer
        Dim sumaAreas, mayorArea, base, altura, area As Decimal
        'Usamos : para asignar valores a un grupo de variables en una misma línea
        cantidadR = 0 : sumaAreas = 0 : mayorArea = 0
        Do
            If area > mayorArea Then
                mayorArea = area
            End If
            sumaAreas = sumaAreas + area
            base = Val(InputBox("Introduzca la base "))
            altura = Val(InputBox("Introduzca la altura"))
            area = base * altura

            If base < 0 Or altura < 0 Then
                MsgBox("Rectángulo no válido ")
            Else
                cantidadR = cantidadR + 1
            End If

        Loop While base > 0 And altura > 0

        lbcantidad.Text = ("La cantidad de rectángulos es: " & cantidadR)
        lbSuma.Text = ("La suma de todas las áreas es: " & sumaAreas)
        lbAreaMayor.Text = ("El área mayor es: " & mayorArea)
    End Sub

    Private Sub bsiguiente_Click(sender As Object, e As EventArgs) Handles bsiguiente.Click
        Form3.Show()
        Me.Hide()

    End Sub
End Class