﻿Public Class Form3
    Private Sub bCalcular_Click(sender As Object, e As EventArgs) Handles bCalcular.Click
        Dim x, limite, suma, contador As Integer

        x = Val(tbX.Text)
        limite = Val(tbLimite.Text)
        suma = 0
        contador = 0

        Do Until (suma + (Math.Pow(x, contador))) >= limite
            contador = contador + 1
            suma = suma + (Math.Pow(x, contador))

        Loop

        lbCantidad.Text="La cantidad de términos es: " & contador
        lbSuma.Text = "La suma es: " & suma
    End Sub
End Class