﻿Public Class Form1
    Private Sub bCalcular_Click(sender As Object, e As EventArgs) Handles bCalcular.Click
        Dim num, a, b, c As Integer
        a = 0 'valor de fibonacci
        b = 1
        c = 1
        num = Val(tbLimite.Text)

        While (a <= num)
            MsgBox(a)
            c = a + b
            a = b
            b = c
        End While
    End Sub

    Private Sub Bsiguiente_Click(sender As Object, e As EventArgs) Handles Bsiguiente.Click
        Form2.Show()
        Me.Hide()
    End Sub
End Class
