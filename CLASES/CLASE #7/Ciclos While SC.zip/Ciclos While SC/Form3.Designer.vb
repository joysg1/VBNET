﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbX = New System.Windows.Forms.TextBox()
        Me.tbLimite = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lbSuma = New System.Windows.Forms.Label()
        Me.lbCantidad = New System.Windows.Forms.Label()
        Me.bCalcular = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(221, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(309, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Serie x^1+x^2+x^3+x^n"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(95, 118)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 21)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Valor de X"
        '
        'tbX
        '
        Me.tbX.Location = New System.Drawing.Point(250, 118)
        Me.tbX.Name = "tbX"
        Me.tbX.Size = New System.Drawing.Size(100, 22)
        Me.tbX.TabIndex = 2
        '
        'tbLimite
        '
        Me.tbLimite.Location = New System.Drawing.Point(250, 175)
        Me.tbLimite.Name = "tbLimite"
        Me.tbLimite.Size = New System.Drawing.Size(100, 22)
        Me.tbLimite.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(95, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 21)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Límite"
        '
        'lbSuma
        '
        Me.lbSuma.AutoSize = True
        Me.lbSuma.Location = New System.Drawing.Point(95, 274)
        Me.lbSuma.Name = "lbSuma"
        Me.lbSuma.Size = New System.Drawing.Size(0, 21)
        Me.lbSuma.TabIndex = 5
        '
        'lbCantidad
        '
        Me.lbCantidad.AutoSize = True
        Me.lbCantidad.Location = New System.Drawing.Point(95, 340)
        Me.lbCantidad.Name = "lbCantidad"
        Me.lbCantidad.Size = New System.Drawing.Size(0, 21)
        Me.lbCantidad.TabIndex = 6
        '
        'bCalcular
        '
        Me.bCalcular.Location = New System.Drawing.Point(504, 188)
        Me.bCalcular.Name = "bCalcular"
        Me.bCalcular.Size = New System.Drawing.Size(127, 41)
        Me.bCalcular.TabIndex = 7
        Me.bCalcular.Text = "Calcular"
        Me.bCalcular.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.bCalcular)
        Me.Controls.Add(Me.lbCantidad)
        Me.Controls.Add(Me.lbSuma)
        Me.Controls.Add(Me.tbLimite)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbX)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form3"
        Me.Text = "Do Until"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbX As TextBox
    Friend WithEvents tbLimite As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lbSuma As Label
    Friend WithEvents lbCantidad As Label
    Friend WithEvents bCalcular As Button
End Class
