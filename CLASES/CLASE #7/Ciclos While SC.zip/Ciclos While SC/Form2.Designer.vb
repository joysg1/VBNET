﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.bCalcular = New System.Windows.Forms.Button()
        Me.bsiguiente = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbcantidad = New System.Windows.Forms.Label()
        Me.lbSuma = New System.Windows.Forms.Label()
        Me.lbAreaMayor = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(201, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(320, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Área de los rectángulos "
        '
        'bCalcular
        '
        Me.bCalcular.Location = New System.Drawing.Point(195, 124)
        Me.bCalcular.Name = "bCalcular"
        Me.bCalcular.Size = New System.Drawing.Size(83, 34)
        Me.bCalcular.TabIndex = 1
        Me.bCalcular.Text = "Calcular"
        Me.bCalcular.UseVisualStyleBackColor = True
        '
        'bsiguiente
        '
        Me.bsiguiente.Location = New System.Drawing.Point(446, 124)
        Me.bsiguiente.Name = "bsiguiente"
        Me.bsiguiente.Size = New System.Drawing.Size(75, 34)
        Me.bsiguiente.TabIndex = 2
        Me.bsiguiente.Text = "Siguiente"
        Me.bsiguiente.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbAreaMayor)
        Me.GroupBox1.Controls.Add(Me.lbSuma)
        Me.GroupBox1.Controls.Add(Me.lbcantidad)
        Me.GroupBox1.Location = New System.Drawing.Point(82, 239)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(569, 186)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Resultados"
        '
        'lbcantidad
        '
        Me.lbcantidad.AutoSize = True
        Me.lbcantidad.Location = New System.Drawing.Point(44, 40)
        Me.lbcantidad.Name = "lbcantidad"
        Me.lbcantidad.Size = New System.Drawing.Size(0, 21)
        Me.lbcantidad.TabIndex = 0
        '
        'lbSuma
        '
        Me.lbSuma.AutoSize = True
        Me.lbSuma.Location = New System.Drawing.Point(44, 81)
        Me.lbSuma.Name = "lbSuma"
        Me.lbSuma.Size = New System.Drawing.Size(0, 21)
        Me.lbSuma.TabIndex = 1
        '
        'lbAreaMayor
        '
        Me.lbAreaMayor.AutoSize = True
        Me.lbAreaMayor.Location = New System.Drawing.Point(44, 116)
        Me.lbAreaMayor.Name = "lbAreaMayor"
        Me.lbAreaMayor.Size = New System.Drawing.Size(0, 21)
        Me.lbAreaMayor.TabIndex = 2
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.bsiguiente)
        Me.Controls.Add(Me.bCalcular)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Do While"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents bCalcular As Button
    Friend WithEvents bsiguiente As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lbAreaMayor As Label
    Friend WithEvents lbSuma As Label
    Friend WithEvents lbcantidad As Label
End Class
